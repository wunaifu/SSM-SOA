## 启动nginx

有很多种方法启动nginx

* (1)直接双击nginx.exe，双击后一个黑色的弹窗一闪而过

* (2)打开cmd命令窗口，切换到nginx解压目录下，输入命令 nginx.exe 或者 start nginx ，回车即可

## 检查nginx是否启动成功

* 直接在浏览器地址栏输入网址 http://localhost:80，回车，出现欢迎页面说明启动成功

* 也可以在cmd命令窗口输入命令 tasklist /fi "imagename eq nginx.exe" 

检查80端口是否被占用的命令是： netstat -ano | findstr 0.0.0.0:80 或 netstat -ano | findstr "80"

## 修改nginx的配置文件nginx.conf
不需要关闭nginx后重新启动nginx，只需要执行命令 nginx -s reload 即可让改动生效

## 关闭nginx

如果使用cmd命令窗口启动nginx，关闭cmd窗口是不能结束nginx进程的，可使用两种方法关闭nginx

* (1)输入nginx命令  nginx -s stop(快速停止nginx)  或  nginx -s quit(完整有序的停止nginx)

* (2)使用taskkill   taskkill /f /t /im nginx.exe